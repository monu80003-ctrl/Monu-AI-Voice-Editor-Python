MONU AI — ANT DOWNLOAD FAILURE FIX

Log में साफ error था:
  Downloading https://archive.apache.org/dist/ant/binaries/apache-ant-1.9.4-bin.tar.gz
  OSError: [Errno 101] Network is unreachable

समाधान:
- GitHub Actions runner के apt packages से ant install होगा।
- buildozer.spec में android.ant_path = /usr/share/ant सेट है।
- इससे Buildozer पुरानी Apache archive URL से Ant डाउनलोड करने की कोशिश नहीं करेगा।
- Python-for-Android commit pin और arm64-only setting पहले की तरह बनी रहेगी।

GitHub में इन दो existing files को EDIT करके पूरी तरह replace करें:
  1) buildozer.spec
  2) .github/workflows/build-android.yml

फिर Commit changes करके Actions में नया build चलाएं।
यह configuration fix है, APK नहीं। अगले run से पता चलेगा कि Ant step पार हुआ या नहीं।
