[app]
title = Monu AI Voice Editor
package.name = monuaivoiceeditor
package.domain = org.monu
source.dir = .
source.include_exts = py,kv,png,jpg,atlas,json,txt
version = 0.1.0
requirements = python3,kivy==2.3.0,requests,plyer
orientation = portrait
android.permissions = INTERNET,READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,RECORD_AUDIO
android.api = 33
android.minapi = 23
android.archs = arm64-v8a
android.enable_androidx = True

[buildozer]
log_level = 2
warn_on_root = 1
