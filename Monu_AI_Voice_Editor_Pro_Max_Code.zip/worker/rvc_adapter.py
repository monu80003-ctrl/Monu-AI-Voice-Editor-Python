import os
import shlex
import subprocess
from pathlib import Path

def _execute(env_name: str, **values):
    template = os.getenv(env_name, "").strip()
    if not template:
        raise RuntimeError(f"{env_name} is missing; configure the selected RVC fork CLI")
    command = template.format(**{key: str(value) for key, value in values.items()})
    result = subprocess.run(shlex.split(command), capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout)[-5000:])

def infer(input_audio: str, model_path: str, output_audio: str):
    Path(output_audio).parent.mkdir(parents=True, exist_ok=True)
    _execute("RVC_INFER_COMMAND", input_audio=input_audio, model_path=model_path, output_audio=output_audio)
    if not Path(output_audio).is_file():
        raise RuntimeError("RVC inference did not create output audio")
    return output_audio

def train(dataset_dir: str, experiment: str, output_dir: str):
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    _execute("RVC_TRAIN_COMMAND", dataset_dir=dataset_dir, experiment=experiment, output_dir=output_dir)
    return output_dir
