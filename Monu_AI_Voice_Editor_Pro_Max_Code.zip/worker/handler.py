import os
import uuid
from pathlib import Path
import runpod
from rvc_adapter import infer, train

ROOT = Path(os.getenv("WORK_DIR", "/workspace/jobs"))
ROOT.mkdir(parents=True, exist_ok=True)

def handler(event):
    payload = event.get("input", {})
    job_dir = ROOT / str(uuid.uuid4())
    job_dir.mkdir(parents=True, exist_ok=True)
    task = payload.get("task", "infer")
    if task == "infer":
        source = payload.get("input_audio_path")
        model = payload.get("model_path")
        if not source or not model:
            raise ValueError("input_audio_path and model_path are required")
        output = str(job_dir / "converted.wav")
        infer(source, model, output)
        return {"status": "completed", "output_audio_path": output}
    if task == "train":
        dataset = payload.get("dataset_dir")
        if not dataset:
            raise ValueError("dataset_dir is required")
        output_dir = str(job_dir / "model")
        train(dataset, payload.get("experiment", "monu_voice"), output_dir)
        return {"status": "completed", "model_dir": output_dir}
    raise ValueError("task must be infer or train")

runpod.serverless.start({"handler": handler})
