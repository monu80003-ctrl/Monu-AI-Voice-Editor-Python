# Monu AI Voice Editor Pro — Maximum Code Pack

यह एक single ZIP में व्यवस्थित, अधिकतम व्यावहारिक source-code package है। इसे **working foundation / integration-ready scaffold** समझें, production-ready app नहीं।

## इसमें क्या है
- Android Kivy client: register/login, project बनाना, वीडियो upload, profile sample upload, render job status और MP4 download के शुरुआती flows।
- FastAPI: JWT auth, user-scoped profiles/projects/jobs, upload validation, profile deletion, timeline save, render queue, download।
- PostgreSQL + Redis + Celery।
- FFmpeg: audio extraction, trim, audio replacement, subtitle burn-in, text overlays और basic image overlays।
- RunPod Serverless API client और worker handler।
- Configurable RVC inference/training adapter।
- GitHub Actions APK build और backend syntax check।
- Docker Compose और deployment guide।

## अभी भी क्या manually configure / implement करना होगा
1. RunPod account में GPU endpoint deploy करना, API key/endpoint ID सेट करना।
2. RVC fork चुनना और उसके exact CLI flags के अनुसार `worker/rvc_adapter.py` के environment command templates सेट करना। RVC model weights और training dataset ZIP में नहीं हैं।
3. RunPod jobs के लिए secure object storage (S3-compatible) में input/model upload और output download adapter configure करना। Worker local path contract देता है; RunPod serverless filesystem ephemeral होता है।
4. Production security: HTTPS, refresh-token rotation, email verification, rate limiting, encryption at rest, malware scanning, signed URLs, audit logs, retention/deletion verification।
5. Android Storage Access Framework (SAF) file picker और वास्तविक फोन पर permission testing।
6. Full visual timeline UI: वर्तमान Android UI project controls देता है; multi-track drag/drop waveform timeline अभी नहीं बनी। Timeline JSON API और FFmpeg render backend का आधार शामिल है।
7. Real device testing, APK signing secrets और signed release build।

## Backend local run
```bash
cp .env.example .env
# .env में secrets बदलें
docker compose up --build
```
API docs: `http://localhost:8000/docs`

## RunPod worker contract
Worker input:
```json
{
  "task": "infer",
  "input_audio_path": "/workspace/input/source.wav",
  "model_path": "/workspace/models/voice.pth",
  "output_audio_path": "/workspace/output/converted.wav"
}
```
या training:
```json
{
  "task": "train",
  "dataset_dir": "/workspace/datasets/my_voice",
  "experiment": "my_voice",
  "output_dir": "/workspace/models/my_voice"
}
```
ये paths उसी GPU worker container में मौजूद होने चाहिए। API backend से RunPod तक secure file transfer जोड़ना deployment-specific अगला काम है।

## RVC command template
Example only; selected fork may use different arguments:
```bash
RVC_INFER_COMMAND=python /opt/rvc/infer_cli.py --input {input_audio} --model {model_path} --output {output_audio}
RVC_TRAIN_COMMAND=python /opt/rvc/train_cli.py --dataset {dataset_dir} --name {experiment} --out {output_dir}
```
Command templates shell से नहीं, `shlex` argument parsing से चलती हैं। पहले अपने fork में commands manually verify करें।

## APK
GitHub Actions → `Build Android Debug APK` चलाएँ। Artifact तभी मिलेगा जब Buildozer/SDK/NDK build सफल हो। Signed release के लिए keystore को GitHub secrets में configure करना होगा; keystore ZIP/repository में न रखें।

केवल अपनी आवाज़ या स्पष्ट अनुमति वाली आवाज़ clone/convert करें।
