import uuid
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session
from .config import settings
from .db import Base, engine, get_db
from .models import User, VoiceProfile, Project, Job
from .security import hash_password, verify_password, make_token, get_current_user
from .media import probe, extract_audio
from .tasks import render_project

Base.metadata.create_all(bind=engine)
Path(settings.storage_dir).mkdir(parents=True, exist_ok=True)
app = FastAPI(title="Monu AI Voice Editor Pro API", version="1.0.0")

class Credentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)

class ProjectCreate(BaseModel):
    title: str = "New project"
    timeline: dict = Field(default_factory=lambda: {"start": 0, "end": None, "overlays": [], "tracks": []})

def save_upload(upload: UploadFile, user_id: str, category: str, allowed: set[str], max_mb: int):
    ext = Path(upload.filename or "").suffix.lower()
    if ext not in allowed:
        raise HTTPException(400, "Unsupported file format")
    folder = Path(settings.storage_dir) / user_id / category
    folder.mkdir(parents=True, exist_ok=True)
    destination = folder / f"{uuid.uuid4()}{ext}"
    total = 0
    try:
        with destination.open("wb") as output:
            while True:
                chunk = upload.file.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_mb * 1024 * 1024:
                    raise HTTPException(413, "Upload exceeds size limit")
                output.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    finally:
        upload.file.close()
    return str(destination)

@app.get("/")
def root():
    return {"name": "Monu AI Voice Editor Pro", "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "ok", "rvc_configured": bool(settings.runpod_endpoint_id and settings.runpod_api_key)}

@app.post("/auth/register")
def register(data: Credentials, db: Session = Depends(get_db)):
    email = data.email.lower()
    if db.query(User).filter_by(email=email).first():
        raise HTTPException(409, "Email already registered")
    user = User(email=email, password_hash=hash_password(data.password))
    db.add(user); db.commit(); db.refresh(user)
    return {"access_token": make_token(user.id), "token_type": "bearer"}

@app.post("/auth/login")
def login(data: Credentials, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=data.email.lower()).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return {"access_token": make_token(user.id), "token_type": "bearer"}

@app.get("/me")
def me(user: User = Depends(get_current_user)):
    return {"id": user.id, "email": user.email}

@app.post("/profiles")
def create_profile(name: str = Form(...), consent: bool = Form(...), audio: UploadFile = File(...),
                   user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not consent:
        raise HTTPException(403, "Voice-owner consent is required")
    path = save_upload(audio, user.id, "profiles", {".wav", ".mp3", ".m4a", ".flac"}, settings.max_audio_mb)
    profile = VoiceProfile(owner_id=user.id, name=name[:120], sample_path=path, consent=True)
    db.add(profile); db.commit(); db.refresh(profile)
    return {"id": profile.id, "status": profile.status,
            "message": "Sample stored. RVC training must be configured and launched on your RunPod worker."}

@app.get("/profiles")
def list_profiles(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return [{"id": p.id, "name": p.name, "status": p.status} for p in db.query(VoiceProfile).filter_by(owner_id=user.id).all()]

@app.delete("/profiles/{profile_id}")
def delete_profile(profile_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(VoiceProfile).filter_by(id=profile_id, owner_id=user.id).first()
    if not profile:
        raise HTTPException(404, "Profile not found")
    for path in (profile.sample_path, profile.model_path):
        if path and Path(path).exists():
            Path(path).unlink()
    db.delete(profile); db.commit()
    return {"deleted": True}

@app.post("/projects")
def create_project(data: ProjectCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    project = Project(owner_id=user.id, title=data.title[:180], timeline=data.timeline)
    db.add(project); db.commit(); db.refresh(project)
    return {"id": project.id, "title": project.title, "timeline": project.timeline}

@app.get("/projects")
def list_projects(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return [{"id": p.id, "title": p.title, "timeline": p.timeline} for p in db.query(Project).filter_by(owner_id=user.id).all()]

@app.patch("/projects/{project_id}/timeline")
def update_timeline(project_id: str, timeline: dict, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    project = db.query(Project).filter_by(id=project_id, owner_id=user.id).first()
    if not project:
        raise HTTPException(404, "Project not found")
    project.timeline = timeline; db.commit()
    return {"id": project.id, "timeline": project.timeline}

@app.post("/projects/{project_id}/source")
def upload_source(project_id: str, video: UploadFile = File(...), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    project = db.query(Project).filter_by(id=project_id, owner_id=user.id).first()
    if not project:
        raise HTTPException(404, "Project not found")
    path = save_upload(video, user.id, "videos", {".mp4", ".mov", ".mkv"}, settings.max_video_mb)
    project.source_path = path; db.commit()
    try:
        metadata = probe(path)
    except Exception:
        metadata = {"probe": "failed"}
    return {"uploaded": True, "metadata": metadata}

@app.post("/projects/{project_id}/extract-audio")
def extract_project_audio(project_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    project = db.query(Project).filter_by(id=project_id, owner_id=user.id).first()
    if not project or not project.source_path:
        raise HTTPException(404, "Project source not found")
    output = str(Path(settings.storage_dir) / user.id / "audio" / f"{project.id}.wav")
    extract_audio(project.source_path, output)
    return {"audio_path": output, "message": "Audio extracted on backend"}

@app.post("/projects/{project_id}/render")
def render(project_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    project = db.query(Project).filter_by(id=project_id, owner_id=user.id).first()
    if not project or not project.source_path:
        raise HTTPException(404, "Project or source video not found")
    job = Job(owner_id=user.id, kind="render", payload={"project_id": project.id})
    db.add(job); db.commit(); db.refresh(job)
    render_project.delay(job.id)
    return {"job_id": job.id, "status": job.status}

@app.get("/jobs/{job_id}")
def job_status(job_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    job = db.query(Job).filter_by(id=job_id, owner_id=user.id).first()
    if not job:
        raise HTTPException(404, "Job not found")
    return {"id": job.id, "status": job.status, "progress": job.progress, "error": job.error}

@app.get("/jobs/{job_id}/download")
def download(job_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    job = db.query(Job).filter_by(id=job_id, owner_id=user.id).first()
    if not job or not job.result_path or not Path(job.result_path).exists():
        raise HTTPException(404, "Output not ready")
    return FileResponse(job.result_path, media_type="video/mp4", filename="monu-edited.mp4")
