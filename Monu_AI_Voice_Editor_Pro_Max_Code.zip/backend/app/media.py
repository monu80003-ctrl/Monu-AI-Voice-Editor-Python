import subprocess, json
from pathlib import Path

def run_ffmpeg(args: list[str]):
    result = subprocess.run(args, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout)[-5000:])
    return result.stdout

def probe(path: str) -> dict:
    raw = run_ffmpeg(["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", path])
    return json.loads(raw)

def extract_audio(video: str, output_wav: str):
    Path(output_wav).parent.mkdir(parents=True, exist_ok=True)
    run_ffmpeg(["ffmpeg", "-y", "-i", video, "-vn", "-ac", "1", "-ar", "40000", output_wav])
    return output_wav

def render_timeline(source: str, output: str, timeline: dict, replacement_audio: str | None = None):
    start = max(0.0, float(timeline.get("start", 0)))
    args = ["ffmpeg", "-y", "-ss", str(start), "-i", source]
    if replacement_audio:
        args += ["-i", replacement_audio]
    end = timeline.get("end")
    if end is not None:
        args += ["-t", str(max(0.05, float(end) - start))]
    filters = []
    subtitle = timeline.get("subtitle_file")
    if subtitle:
        subtitle_path = str(Path(subtitle).resolve()).replace("\\\\", "/").replace(":", r"\\:")
        filters.append(f"subtitles='{subtitle_path}'")
    for overlay in timeline.get("overlays", []):
        kind = overlay.get("type")
        x, y = int(overlay.get("x", 40)), int(overlay.get("y", 40))
        if kind == "text":
            text = str(overlay.get("text", "")).replace("\\\\", r"\\\\").replace("'", r"\\'").replace(":", r"\\:")
            filters.append(f"drawtext=text='{text}':x={x}:y={y}:fontsize={int(overlay.get('font_size',36))}:fontcolor=white:box=1:boxcolor=black@0.45")
    if filters:
        args += ["-vf", ",".join(filters)]
    if replacement_audio:
        args += ["-map", "0:v:0", "-map", "1:a:0", "-shortest"]
    args += ["-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
             "-c:a", "aac", "-movflags", "+faststart", output]
    run_ffmpeg(args)
    return output
