from celery import Celery
from pathlib import Path
from .config import settings
from .db import SessionLocal
from .models import Job, Project
from .media import render_timeline

celery_app = Celery("monu_voice", broker=settings.redis_url, backend=settings.redis_url)
celery_app.conf.update(task_track_started=True, accept_content=["json"], task_serializer="json", result_serializer="json")

@celery_app.task(name="render_project")
def render_project(job_id: str):
    db = SessionLocal()
    job = None
    try:
        job = db.get(Job, job_id)
        if not job:
            return
        job.status, job.progress = "processing", 5
        db.commit()
        project = db.get(Project, job.payload["project_id"])
        if not project or not project.source_path:
            raise RuntimeError("Project source video is missing")
        output_dir = Path(settings.storage_dir) / "outputs"
        output_dir.mkdir(parents=True, exist_ok=True)
        output = str(output_dir / f"{job.id}.mp4")
        render_timeline(project.source_path, output, project.timeline or {})
        job.result_path, job.status, job.progress = output, "completed", 100
        db.commit()
    except Exception as exc:
        if job:
            job.status, job.error = "failed", str(exc)[:3000]
            db.commit()
        raise
    finally:
        db.close()
