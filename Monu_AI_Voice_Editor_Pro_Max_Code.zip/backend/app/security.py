from datetime import datetime, timedelta, timezone
import jwt
from pwdlib import PasswordHash
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from .config import settings
from .db import get_db
from .models import User

password_hasher = PasswordHash.recommended()
oauth_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

def hash_password(password: str) -> str:
    if len(password) < 10:
        raise ValueError("Password must contain at least 10 characters")
    return password_hasher.hash(password)

def verify_password(password: str, encoded: str) -> bool:
    return password_hasher.verify(password, encoded)

def make_token(user_id: str) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode({"sub": user_id, "iat": now, "exp": now + timedelta(minutes=settings.access_token_minutes)},
                      settings.jwt_secret, algorithm="HS256")

def get_current_user(token: str = Depends(oauth_scheme), db: Session = Depends(get_db)):
    try:
        user_id = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])["sub"]
    except jwt.PyJWTError:
        raise HTTPException(401, "Invalid or expired access token")
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(401, "User not found")
    return user
