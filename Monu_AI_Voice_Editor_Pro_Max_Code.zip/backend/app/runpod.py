import httpx
from .config import settings

class RunPodClient:
    def _url(self, action: str):
        if not settings.runpod_endpoint_id or not settings.runpod_api_key:
            raise RuntimeError("RUNPOD_ENDPOINT_ID and RUNPOD_API_KEY are not configured")
        return f"https://api.runpod.ai/v2/{settings.runpod_endpoint_id}/{action}"

    async def run(self, payload: dict):
        async with httpx.AsyncClient(timeout=settings.runpod_timeout_seconds) as client:
            response = await client.post(self._url("run"),
                headers={"Authorization": f"Bearer {settings.runpod_api_key}"},
                json={"input": payload})
            response.raise_for_status()
            return response.json()

    async def status(self, runpod_job_id: str):
        async with httpx.AsyncClient(timeout=45) as client:
            response = await client.get(self._url("status/" + runpod_job_id),
                headers={"Authorization": f"Bearer {settings.runpod_api_key}"})
            response.raise_for_status()
            return response.json()
