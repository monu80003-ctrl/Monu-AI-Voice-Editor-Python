from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    jwt_secret: str = "CHANGE_ME"
    access_token_minutes: int = 45
    database_url: str = "sqlite:///./dev.db"
    redis_url: str = "redis://localhost:6379/0"
    storage_dir: str = "./data"
    max_audio_mb: int = 100
    max_video_mb: int = 800
    runpod_api_key: str = ""
    runpod_endpoint_id: str = ""
    runpod_timeout_seconds: int = 900
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
