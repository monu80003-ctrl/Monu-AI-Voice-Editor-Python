from pathlib import Path
import ast

def test_app_python_files_parse():
    app_dir = Path(__file__).parents[1] / "app"
    for file in app_dir.glob("*.py"):
        ast.parse(file.read_text(encoding="utf-8"))
