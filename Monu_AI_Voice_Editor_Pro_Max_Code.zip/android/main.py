import threading
from pathlib import Path
import requests
from kivy.app import App
from kivy.lang import Builder
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock
from plyer import filechooser

KV = '''
<Root>:
    orientation: 'vertical'
    padding: '10dp'
    spacing: '5dp'
    Label:
        text: '[b]MONU AI VOICE EDITOR PRO[/b]'
        markup: True
        size_hint_y: None
        height: '42dp'
    TextInput:
        id: api
        text: root.api_url
        hint_text: 'HTTPS API URL'
        multiline: False
        size_hint_y: None
        height: '42dp'
    TextInput:
        id: email
        hint_text: 'Email'
        multiline: False
        size_hint_y: None
        height: '42dp'
    TextInput:
        id: password
        hint_text: 'Password (minimum 10 characters)'
        password: True
        multiline: False
        size_hint_y: None
        height: '42dp'
    BoxLayout:
        size_hint_y: None
        height: '42dp'
        Button:
            text: 'Register'
            on_release: root.authenticate('/auth/register')
        Button:
            text: 'Login'
            on_release: root.authenticate('/auth/login')
    Button:
        text: 'Create Project'
        size_hint_y: None
        height: '42dp'
        on_release: root.create_project()
    Button:
        text: 'Choose Video'
        size_hint_y: None
        height: '42dp'
        on_release: root.choose_video()
    Label:
        text: root.video_name
        size_hint_y: None
        height: '30dp'
    Button:
        text: 'Upload Video'
        size_hint_y: None
        height: '42dp'
        on_release: root.upload_video()
    Button:
        text: 'Render MP4'
        size_hint_y: None
        height: '45dp'
        on_release: root.render()
    Label:
        text: root.status
        text_size: self.width, None
'''

class Root(BoxLayout):
    api_url = StringProperty('')
    token = StringProperty('')
    project_id = StringProperty('')
    video_path = StringProperty('')
    video_name = StringProperty('No video selected')
    status = StringProperty('Register or login to start')

    def headers(self):
        return {'Authorization': 'Bearer ' + self.token} if self.token else {}

    def authenticate(self, route):
        self.api_url = self.ids.api.text.strip().rstrip('/')
        threading.Thread(target=self._auth, args=(route, self.ids.email.text.strip(), self.ids.password.text), daemon=True).start()

    def _auth(self, route, email, password):
        try:
            response = requests.post(self.api_url + route, json={'email': email, 'password': password}, timeout=30)
            response.raise_for_status()
            self.token = response.json()['access_token']
            self.set_status('Login successful')
        except Exception as exc:
            self.set_status(str(exc))

    def create_project(self):
        threading.Thread(target=self._create_project, daemon=True).start()

    def _create_project(self):
        try:
            response = requests.post(self.api_url + '/projects', headers=self.headers(),
                json={'title': 'Mobile project', 'timeline': {'start': 0, 'end': None, 'overlays': [], 'tracks': []}}, timeout=30)
            response.raise_for_status()
            self.project_id = response.json()['id']
            self.set_status('Project created')
        except Exception as exc:
            self.set_status(str(exc))

    def choose_video(self):
        filechooser.open_file(on_selection=self._video_selected, filters=['*.mp4', '*.mov', '*.mkv'])

    def _video_selected(self, paths):
        if paths:
            self.video_path = paths[0]
            self.video_name = Path(paths[0]).name

    def upload_video(self):
        threading.Thread(target=self._upload, daemon=True).start()

    def _upload(self):
        try:
            with open(self.video_path, 'rb') as source:
                response = requests.post(self.api_url + f'/projects/{self.project_id}/source',
                    headers=self.headers(), files={'video': (Path(self.video_path).name, source)}, timeout=600)
            response.raise_for_status()
            self.set_status('Video uploaded')
        except Exception as exc:
            self.set_status(str(exc))

    def render(self):
        threading.Thread(target=self._render, daemon=True).start()

    def _render(self):
        try:
            response = requests.post(self.api_url + f'/projects/{self.project_id}/render', headers=self.headers(), timeout=60)
            response.raise_for_status()
            self.set_status('Render queued: ' + response.json()['job_id'])
        except Exception as exc:
            self.set_status(str(exc))

    def set_status(self, message):
        Clock.schedule_once(lambda dt: setattr(self, 'status', message), 0)

class MonuProApp(App):
    def build(self):
        Builder.load_string(KV)
        return Root()

if __name__ == '__main__':
    MonuProApp().run()
