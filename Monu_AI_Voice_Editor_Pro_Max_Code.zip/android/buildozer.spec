[app]
title = Monu AI Voice Editor Pro
package.name = monuaivoicepro
package.domain = com.monu.ai
source.dir = .
source.include_exts = py,kv,png,jpg,json
version = 1.0.0
requirements = python3,kivy==2.3.0,requests,plyer
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE
android.minapi = 23
android.api = 33
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
p4a.bootstrap = sdl2
log_level = 2

[buildozer]
warn_on_root = 1
