# Monu AI Voice Editor Pro — Implementation Foundation

चयन: RunPod GPU + Full editor. यह deployable project foundation है, verified production product नहीं।

## शामिल
- Android Kivy client
- FastAPI login (JWT) और user-owned voice profiles/projects/jobs
- PostgreSQL + Redis + Celery
- FFmpeg extract/render helper
- RunPod Serverless API client
- RunPod worker handler और configurable RVC CLI adapter
- GitHub Actions Android debug APK workflow
- Docker Compose backend

## शुरू करें
1. `.env.example` को `.env` नाम दें। `JWT_SECRET`, `POSTGRES_PASSWORD`, RunPod endpoint और API key बदलें।
2. `docker compose up --build`
3. API docs: `http://localhost:8000/docs`
4. Android build: GitHub Actions → Build Android APK.

## RunPod/RVC की अनिवार्य सेटिंग
RVC fork चुनकर उसकी compatible GPU image बनानी होगी। `worker/rvc_adapter.py` में `RVC_INFER_COMMAND` और `RVC_TRAIN_COMMAND` को उस fork के असली CLI के अनुसार सेट करें। उदाहरण:
`python /workspace/rvc/infer_cli.py --input {input_audio} --model {model_path} --output {output_audio}`
यह केवल उदाहरण है, सार्वभौमिक RVC command नहीं। Model weights, dataset और GPU endpoint आपके RunPod account में होंगे।

## सीमाएँ
यह package source foundation है। इसमें RVC fork/model weights शामिल नहीं; RunPod file transfer के लिए production object storage adapter, full visual timeline UI, advanced multi-track compositor, Android SAF file picker compatibility, end-to-end device tests और signed release secrets अभी configure/test करने होंगे। FFmpeg render helper trim, audio replacement, subtitle और text overlay के basic operations देता है; advanced compositing अगला implementation चरण है। कोई APK अभी built/signed/tested नहीं है।

Production launch से पहले HTTPS, refresh-token rotation, rate limits, encrypted private object storage, signed URLs, cleanup/deletion verification, audit logs और security review जरूरी हैं। केवल अपनी या स्पष्ट अनुमति वाली आवाज़ का उपयोग करें।
