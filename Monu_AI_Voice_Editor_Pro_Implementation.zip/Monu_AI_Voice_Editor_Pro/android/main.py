import threading, requests
from pathlib import Path
from kivy.app import App
from kivy.lang import Builder
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock
from plyer import filechooser
KV='''<Root>:
 orientation:'vertical'
 padding:'10dp'
 spacing:'6dp'
 Label:
  text:'[b]MONU AI VOICE EDITOR PRO[/b]'
  markup:True
  size_hint_y:None
  height:'40dp'
 TextInput:
  id:url
  hint_text:'HTTPS API URL'
  text:root.api_url
  multiline:False
  size_hint_y:None
  height:'42dp'
 TextInput:
  id:email
  hint_text:'Email'
  multiline:False
  size_hint_y:None
  height:'42dp'
 TextInput:
  id:password
  hint_text:'Password (10+ chars)'
  password:True
  multiline:False
  size_hint_y:None
  height:'42dp'
 BoxLayout:
  size_hint_y:None
  height:'42dp'
  Button:
   text:'Register'
   on_release:root.auth('/auth/register')
  Button:
   text:'Login'
   on_release:root.auth('/auth/login')
 Button:
  text:'New Project'
  size_hint_y:None
  height:'42dp'
  on_release:root.new_project()
 Button:
  text:'Choose Video'
  size_hint_y:None
  height:'42dp'
  on_release:root.pick_video()
 Label:
  text:root.video_name
  size_hint_y:None
  height:'30dp'
 Button:
  text:'Upload Video'
  size_hint_y:None
  height:'42dp'
  on_release:root.upload_video()
 Button:
  text:'Render MP4'
  size_hint_y:None
  height:'46dp'
  on_release:root.render()
 Label:
  text:root.status
  text_size:self.width,None
'''
class Root(BoxLayout):
 api_url=StringProperty(''); token=StringProperty(''); project_id=StringProperty('')
 video_path=StringProperty(''); video_name=StringProperty('No video selected'); status=StringProperty('Login to start')
 def headers(self): return {'Authorization':'Bearer '+self.token} if self.token else {}
 def auth(self,route):
  self.api_url=self.ids.url.text.strip().rstrip('/')
  threading.Thread(target=self._auth,args=(route,self.ids.email.text.strip(),self.ids.password.text),daemon=True).start()
 def _auth(self,route,email,password):
  try:
   r=requests.post(self.api_url+route,json={'email':email,'password':password},timeout=30); r.raise_for_status()
   self.token=r.json()['access_token']; self.set_status('Logged in')
  except Exception as e:self.set_status(str(e))
 def new_project(self): threading.Thread(target=self._new_project,daemon=True).start()
 def _new_project(self):
  try:
   r=requests.post(self.api_url+'/projects',headers=self.headers(),json={'title':'Mobile Edit','timeline':{'start':0,'end':None,'overlays':[],'tracks':[]}},timeout=30); r.raise_for_status()
   self.project_id=r.json()['id']; self.set_status('Project created')
  except Exception as e:self.set_status(str(e))
 def pick_video(self): filechooser.open_file(on_selection=self.picked,filters=['*.mp4','*.mov','*.mkv'])
 def picked(self,paths):
  if paths:self.video_path=paths[0]; self.video_name=Path(paths[0]).name
 def upload_video(self): threading.Thread(target=self._upload,daemon=True).start()
 def _upload(self):
  try:
   with open(self.video_path,'rb') as f:
    r=requests.post(self.api_url+f'/projects/{self.project_id}/source',headers=self.headers(),files={'video':(Path(self.video_path).name,f)},timeout=600); r.raise_for_status()
   self.set_status('Video uploaded')
  except Exception as e:self.set_status(str(e))
 def render(self): threading.Thread(target=self._render,daemon=True).start()
 def _render(self):
  try:
   r=requests.post(self.api_url+f'/projects/{self.project_id}/render',headers=self.headers(),timeout=60); r.raise_for_status()
   self.set_status('Render job: '+r.json()['job_id'])
  except Exception as e:self.set_status(str(e))
 def set_status(self,s):Clock.schedule_once(lambda dt:setattr(self,'status',s),0)
class MonuPro(App):
 def build(self):Builder.load_string(KV); return Root()
if __name__=='__main__':MonuPro().run()
