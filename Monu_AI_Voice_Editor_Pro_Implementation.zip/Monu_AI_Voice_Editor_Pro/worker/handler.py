import os, uuid
from pathlib import Path
import runpod
from rvc_adapter import inference, training
ROOT=Path(os.getenv("WORK_DIR","/workspace/jobs")); ROOT.mkdir(parents=True,exist_ok=True)
def handler(event):
    data=event.get("input",{}); job=ROOT/str(uuid.uuid4()); job.mkdir()
    if data.get("task","infer")=="infer":
        out=str(job/"converted.wav")
        inference(data["input_audio_path"],data["model_path"],out)
        return {"status":"completed","output_audio_path":out}
    if data.get("task")=="train":
        out=str(job/"model")
        training(data["dataset_dir"],data.get("experiment","monu_voice"),out)
        return {"status":"completed","model_dir":out}
    raise ValueError("task must be infer or train")
runpod.serverless.start({"handler":handler})
