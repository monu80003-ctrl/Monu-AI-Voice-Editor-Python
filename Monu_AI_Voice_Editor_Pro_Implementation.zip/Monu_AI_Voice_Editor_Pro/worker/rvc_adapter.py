import os, shlex, subprocess
from pathlib import Path
def run_cmd(key, **values):
    template=os.getenv(key,"").strip()
    if not template: raise RuntimeError(key+" is not configured for the selected RVC fork")
    args=shlex.split(template.format(**{k:str(v) for k,v in values.items()}))
    p=subprocess.run(args,capture_output=True,text=True)
    if p.returncode: raise RuntimeError((p.stderr or p.stdout)[-4000:])
def inference(input_audio,model_path,output_audio):
    Path(output_audio).parent.mkdir(parents=True,exist_ok=True)
    run_cmd("RVC_INFER_COMMAND",input_audio=input_audio,model_path=model_path,output_audio=output_audio)
    if not Path(output_audio).exists(): raise RuntimeError("RVC did not create output audio")
    return output_audio
def training(dataset_dir,experiment,output_dir):
    Path(output_dir).mkdir(parents=True,exist_ok=True)
    run_cmd("RVC_TRAIN_COMMAND",dataset_dir=dataset_dir,experiment=experiment,output_dir=output_dir)
    return output_dir
