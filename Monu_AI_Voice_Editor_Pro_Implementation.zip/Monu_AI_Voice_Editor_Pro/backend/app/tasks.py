from celery import Celery
from .config import settings
from .db import SessionLocal
from .models import Job, Project
from .media import render
from pathlib import Path
celery = Celery("monu", broker=settings.redis_url, backend=settings.redis_url)
@celery.task
def render_job(job_id):
    db=SessionLocal()
    try:
        job=db.get(Job,job_id)
        if not job: return
        job.status="processing"; job.progress=10; db.commit()
        project=db.get(Project,job.input_json["project_id"])
        if not project or not project.source_path: raise RuntimeError("Project source missing")
        out=Path(settings.storage_dir)/"outputs"/(job.id+".mp4")
        out.parent.mkdir(parents=True,exist_ok=True)
        render(project.source_path,str(out),project.timeline)
        job.result_path=str(out); job.status="completed"; job.progress=100; db.commit()
    except Exception as e:
        if job: job.status="failed"; job.error=str(e)[:2000]; db.commit()
        raise
    finally: db.close()
