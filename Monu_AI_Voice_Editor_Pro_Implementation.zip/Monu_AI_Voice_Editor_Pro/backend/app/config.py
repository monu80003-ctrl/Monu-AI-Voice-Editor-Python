from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    jwt_secret: str = "CHANGE_ME"
    access_token_minutes: int = 60
    database_url: str = "sqlite:///./dev.db"
    redis_url: str = "redis://localhost:6379/0"
    storage_dir: str = "./data"
    max_upload_mb: int = 500
    runpod_api_key: str = ""
    runpod_endpoint_id: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
settings = Settings()
