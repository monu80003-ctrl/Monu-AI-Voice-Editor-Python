from datetime import datetime, timedelta, timezone
import jwt
from pwdlib import PasswordHash
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from .config import settings
from .db import get_db
from .models import User
hasher = PasswordHash.recommended()
oauth = OAuth2PasswordBearer(tokenUrl="/auth/login")
def hash_password(p):
    if len(p) < 10: raise ValueError("Password must be at least 10 characters")
    return hasher.hash(p)
def check_password(p, h): return hasher.verify(p, h)
def token_for(uid):
    now = datetime.now(timezone.utc)
    return jwt.encode({"sub":uid,"iat":now,"exp":now+timedelta(minutes=settings.access_token_minutes)}, settings.jwt_secret, algorithm="HS256")
def get_user(token: str = Depends(oauth), db: Session = Depends(get_db)):
    try: uid = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])["sub"]
    except Exception: raise HTTPException(401, "Invalid or expired token")
    user = db.get(User, uid)
    if not user: raise HTTPException(401, "User not found")
    return user
