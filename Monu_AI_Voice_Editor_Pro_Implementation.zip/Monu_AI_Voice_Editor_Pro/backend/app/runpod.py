import httpx
from .config import settings
class RunPod:
    def url(self, suffix):
        if not settings.runpod_api_key or not settings.runpod_endpoint_id:
            raise RuntimeError("Configure RUNPOD_API_KEY and RUNPOD_ENDPOINT_ID")
        return f"https://api.runpod.ai/v2/{settings.runpod_endpoint_id}/{suffix}"
    async def submit(self, payload):
        async with httpx.AsyncClient(timeout=45) as c:
            r = await c.post(self.url("run"), headers={"Authorization":f"Bearer {settings.runpod_api_key}"}, json={"input":payload})
            r.raise_for_status()
            return r.json()
    async def status(self, job_id):
        async with httpx.AsyncClient(timeout=45) as c:
            r = await c.get(self.url("status/"+job_id), headers={"Authorization":f"Bearer {settings.runpod_api_key}"})
            r.raise_for_status()
            return r.json()
