import uuid
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr, Field
from .db import Base, engine, get_db
from .models import User, VoiceProfile, Project, Job
from .security import hash_password, check_password, token_for, get_user
from .config import settings
from .tasks import render_job
from .media import probe
Base.metadata.create_all(bind=engine)
Path(settings.storage_dir).mkdir(parents=True,exist_ok=True)
app=FastAPI(title="Monu AI Voice Editor Pro")
class Credentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10,max_length=128)
class ProjectCreate(BaseModel):
    title: str = "New project"
    timeline: dict = Field(default_factory=lambda:{"start":0,"end":None,"overlays":[],"tracks":[]})
def store(file,user,kind,limit):
    ext=Path(file.filename or "").suffix.lower()
    allowed={".wav",".mp3",".m4a",".flac"} if kind=="profiles" else {".mp4",".mov",".mkv"}
    if ext not in allowed: raise HTTPException(400,"Unsupported file type")
    folder=Path(settings.storage_dir)/user.id/kind; folder.mkdir(parents=True,exist_ok=True)
    path=folder/(str(uuid.uuid4())+ext); total=0
    try:
        with path.open("wb") as out:
            while True:
                chunk=file.file.read(1024*1024)
                if not chunk: break
                total+=len(chunk)
                if total>limit*1024*1024: raise HTTPException(413,"Upload too large")
                out.write(chunk)
    except Exception:
        path.unlink(missing_ok=True); raise
    finally: file.file.close()
    return str(path)
@app.get("/health")
def health(): return {"status":"ok","service":"Monu AI Voice Editor Pro"}
@app.post("/auth/register")
def register(data:Credentials,db:Session=Depends(get_db)):
    email=data.email.lower()
    if db.query(User).filter_by(email=email).first(): raise HTTPException(409,"Email already registered")
    user=User(email=email,password_hash=hash_password(data.password)); db.add(user); db.commit(); db.refresh(user)
    return {"access_token":token_for(user.id),"token_type":"bearer"}
@app.post("/auth/login")
def login(data:Credentials,db:Session=Depends(get_db)):
    user=db.query(User).filter_by(email=data.email.lower()).first()
    if not user or not check_password(data.password,user.password_hash): raise HTTPException(401,"Invalid credentials")
    return {"access_token":token_for(user.id),"token_type":"bearer"}
@app.get("/me")
def me(user:User=Depends(get_user)): return {"id":user.id,"email":user.email}
@app.post("/profiles")
def add_profile(name:str=Form(...),consent:bool=Form(...),audio:UploadFile=File(...),user:User=Depends(get_user),db:Session=Depends(get_db)):
    if not consent: raise HTTPException(403,"Voice owner consent required")
    path=store(audio,user,"profiles",50); p=VoiceProfile(owner_id=user.id,name=name,sample_path=path,consent=True)
    db.add(p); db.commit(); db.refresh(p)
    return {"id":p.id,"status":p.status,"note":"Sample stored; training job requires configured RVC worker."}
@app.get("/profiles")
def profiles(user:User=Depends(get_user),db:Session=Depends(get_db)):
    return [{"id":p.id,"name":p.name,"status":p.status} for p in db.query(VoiceProfile).filter_by(owner_id=user.id).all()]
@app.delete("/profiles/{pid}")
def delete_profile(pid:str,user:User=Depends(get_user),db:Session=Depends(get_db)):
    p=db.query(VoiceProfile).filter_by(id=pid,owner_id=user.id).first()
    if not p: raise HTTPException(404,"Profile not found")
    for f in (p.sample_path,p.model_path):
        if f and Path(f).exists(): Path(f).unlink()
    db.delete(p); db.commit(); return {"deleted":True}
@app.post("/projects")
def create_project(data:ProjectCreate,user:User=Depends(get_user),db:Session=Depends(get_db)):
    p=Project(owner_id=user.id,title=data.title,timeline=data.timeline); db.add(p); db.commit(); db.refresh(p)
    return {"id":p.id,"title":p.title,"timeline":p.timeline}
@app.get("/projects")
def projects(user:User=Depends(get_user),db:Session=Depends(get_db)):
    return [{"id":p.id,"title":p.title,"timeline":p.timeline} for p in db.query(Project).filter_by(owner_id=user.id).all()]
@app.patch("/projects/{pid}/timeline")
def timeline(pid:str,data:dict,user:User=Depends(get_user),db:Session=Depends(get_db)):
    p=db.query(Project).filter_by(id=pid,owner_id=user.id).first()
    if not p: raise HTTPException(404,"Project not found")
    p.timeline=data; db.commit(); return {"timeline":p.timeline}
@app.post("/projects/{pid}/source")
def source(pid:str,video:UploadFile=File(...),user:User=Depends(get_user),db:Session=Depends(get_db)):
    p=db.query(Project).filter_by(id=pid,owner_id=user.id).first()
    if not p: raise HTTPException(404,"Project not found")
    p.source_path=store(video,user,"videos",settings.max_upload_mb); db.commit()
    try: meta=probe(p.source_path)
    except Exception: meta={"probe":"not available"}
    return {"uploaded":True,"metadata":meta}
@app.post("/projects/{pid}/render")
def render_project(pid:str,user:User=Depends(get_user),db:Session=Depends(get_db)):
    p=db.query(Project).filter_by(id=pid,owner_id=user.id).first()
    if not p or not p.source_path: raise HTTPException(404,"Project/source missing")
    j=Job(owner_id=user.id,kind="render",input_json={"project_id":p.id}); db.add(j); db.commit(); db.refresh(j)
    render_job.delay(j.id); return {"job_id":j.id,"status":j.status}
@app.get("/jobs/{jid}")
def job(jid:str,user:User=Depends(get_user),db:Session=Depends(get_db)):
    j=db.query(Job).filter_by(id=jid,owner_id=user.id).first()
    if not j: raise HTTPException(404,"Job not found")
    return {"id":j.id,"status":j.status,"progress":j.progress,"error":j.error}
@app.get("/jobs/{jid}/download")
def download(jid:str,user:User=Depends(get_user),db:Session=Depends(get_db)):
    j=db.query(Job).filter_by(id=jid,owner_id=user.id).first()
    if not j or not j.result_path or not Path(j.result_path).exists(): raise HTTPException(404,"Output not ready")
    return FileResponse(j.result_path,media_type="video/mp4",filename="monu-edited.mp4")
