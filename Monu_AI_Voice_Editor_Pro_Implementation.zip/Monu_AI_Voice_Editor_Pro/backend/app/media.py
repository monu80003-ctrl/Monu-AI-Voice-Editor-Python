import subprocess, json
def cmd(args):
    p = subprocess.run(args, capture_output=True, text=True)
    if p.returncode: raise RuntimeError((p.stderr or p.stdout)[-3000:])
    return p.stdout
def probe(path):
    return json.loads(cmd(["ffprobe","-v","error","-show_format","-show_streams","-of","json",path]))
def extract_audio(video, wav):
    cmd(["ffmpeg","-y","-i",video,"-vn","-ac","1","-ar","40000",wav])
def render(source, output, timeline, replacement_audio=None):
    start=max(0,float(timeline.get("start",0)))
    args=["ffmpeg","-y","-ss",str(start),"-i",source]
    if replacement_audio: args += ["-i",replacement_audio]
    end=timeline.get("end")
    if end is not None: args += ["-t",str(max(.05,float(end)-start))]
    vf=[]
    subtitle=timeline.get("subtitle_file")
    if subtitle: vf.append("subtitles="+subtitle.replace(":","\\:"))
    for item in timeline.get("overlays",[]):
        if item.get("type")=="text":
            txt=str(item.get("text","")).replace("'","\\'").replace(":","\\:")
            vf.append(f"drawtext=text='{txt}':x={int(item.get('x',40))}:y={int(item.get('y',40))}:fontsize=36:fontcolor=white:box=1:boxcolor=black@0.5")
    if vf: args += ["-vf",",".join(vf)]
    if replacement_audio: args += ["-map","0:v:0","-map","1:a:0","-shortest"]
    args += ["-c:v","libx264","-preset","veryfast","-c:a","aac","-pix_fmt","yuv420p","-movflags","+faststart",output]
    cmd(args)
    return output
