"""Compatibility entrypoint for local API development.
The canonical FastAPI application lives in server/app.py.
"""
from server.app import app

__all__ = ["app"]
