# Monu AI Voice Editor — Python Starter

यह ZIP एक व्यवस्थित starter repository है। इसमें Android Kivy UI, FastAPI upload API और GitHub Actions से APK build की configuration है।

## फोल्डर संरचना

```text
Monu-AI-Voice-Editor/
├── main.py
├── app.py
├── buildozer.spec
├── requirements.txt
├── README_HINDI.md
├── server/
│   ├── __init__.py
│   ├── app.py
│   └── requirements.txt
└── .github/
    └── workflows/
        └── build-android.yml
```

## GitHub में लगाने का तरीका

1. पहले अपनी मौजूदा repository का backup/ZIP डाउनलोड कर लें।
2. ZIP को अपने फोन या कंप्यूटर पर extract करें।
3. GitHub repository में मौजूद फाइलों को एक-एक करके इसी path की फाइलों से replace करें।
4. नई फाइलें/फोल्डर बनाते समय पूरा path लिखें। उदाहरण: `server/app.py` और `.github/workflows/build-android.yml`।
5. ZIP फाइल को repository में डालना आवश्यक नहीं है; उसके अंदर की फाइलें सही paths पर डालें।
6. सभी बदलाव commit करने के बाद GitHub में Actions टैब खोलें और `Build Monu AI Voice Editor APK` workflow चलाएँ।
7. सफल build के बाद Actions run के Artifacts भाग से APK artifact डाउनलोड करें।

## Cloud API चलाना

Python server वाले environment में:

```bash
cd server
python -m pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

API documentation: `http://SERVER:8000/docs`

## बहुत जरूरी सीमा

यह अभी starter है, पूरा voice editor नहीं। इसमें:
- Android UI और API पर sample/video upload request है।
- Voice profile upload का ID app में सेव होता है।
- API file upload और job placeholder देती है।

अभी इसमें **वास्तविक RVC training/inference worker, GPU job queue, FFmpeg से audio निकालना/वापस video में जोड़ना, converted MP4 download, user login/authentication, encrypted profile storage और पूर्ण Android file-picker compatibility** लागू/टेस्ट नहीं हैं। इसलिए अभी यह वास्तविक आवाज़ बदलकर output video नहीं बनाएगा।

केवल अपनी आवाज़ या स्पष्ट अनुमति वाली आवाज़ का उपयोग करें। Server पर authentication और private storage लगाए बिना इसे सार्वजनिक इंटरनेट पर संवेदनशील voice samples के लिए deploy न करें।

## Android file access नोट

Android 11 पर file picker से मिलने वाला URI कभी-कभी साधारण filesystem path नहीं होता। इस starter के Plyer file picker को वास्तविक Samsung डिवाइस पर test और आवश्यकतानुसार Android Storage Access Framework के साथ सुधारना होगा।

## Build नोट

GitHub Actions workflow APK build का प्रयास करता है; सफल build की गारंटी नहीं। Buildozer/Android SDK/NDK compatibility के कारण workflow में आगे बदलाव की जरूरत हो सकती है। APK को वास्तविक Android डिवाइस पर install करके test करना बाकी है।
