import json
import os
import threading
from pathlib import Path

import requests
from kivy.app import App
from kivy.lang import Builder
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock
from plyer import filechooser

APP_DIR = Path(os.environ.get("ANDROID_PRIVATE", str(Path.home()))) / "monu_voice_editor"
APP_DIR.mkdir(parents=True, exist_ok=True)
CONFIG_FILE = APP_DIR / "settings.json"

KV = r"""
<Root>:
    orientation: "vertical"
    padding: "14dp"
    spacing: "8dp"
    Label:
        text: "[b]MONU AI VOICE EDITOR[/b]\\n[size=13sp]Voice Conversion Studio[/size]"
        markup: True
        size_hint_y: None
        height: "60dp"
    TextInput:
        id: api
        hint_text: "Cloud API URL (https://your-server)"
        text: root.api_url
        multiline: False
        size_hint_y: None
        height: "48dp"
    Button:
        text: "API URL सेव करें"
        size_hint_y: None
        height: "44dp"
        on_release: root.save_api(api.text)
    Label:
        text: "1. अपनी या अनुमति-प्राप्त आवाज़ का sample चुनें"
        size_hint_y: None
        height: "40dp"
    Button:
        text: "Voice Sample चुनें"
        size_hint_y: None
        height: "46dp"
        on_release: root.choose_sample()
    Label:
        text: root.sample_name
        size_hint_y: None
        height: "30dp"
    Button:
        text: "Voice Sample Upload करें"
        size_hint_y: None
        height: "46dp"
        on_release: root.upload_sample()
    Label:
        text: root.profile_status
        size_hint_y: None
        height: "38dp"
    Label:
        text: "2. वह वीडियो चुनें जिसकी आवाज़ बदलनी है"
        size_hint_y: None
        height: "40dp"
    Button:
        text: "वीडियो चुनें"
        size_hint_y: None
        height: "46dp"
        on_release: root.choose_video()
    Label:
        text: root.video_name
        size_hint_y: None
        height: "30dp"
    Button:
        text: "Conversion Job भेजें"
        size_hint_y: None
        height: "50dp"
        on_release: root.convert()
    Label:
        text: root.status
        text_size: self.width, None
        halign: "left"
        valign: "middle"
    Label:
        text: "नोट: यह starter app है। RVC GPU worker और FFmpeg pipeline अभी कनेक्ट नहीं हैं; अभी वास्तविक आवाज़ conversion नहीं होगा।"
        text_size: self.width, None
        size_hint_y: None
        height: "68dp"
"""

class Root(BoxLayout):
    api_url = StringProperty("")
    sample_path = StringProperty("")
    video_path = StringProperty("")
    sample_name = StringProperty("कोई sample नहीं चुना")
    video_name = StringProperty("कोई वीडियो नहीं चुना")
    profile_id = StringProperty("")
    profile_status = StringProperty("Voice profile अभी upload नहीं हुआ")
    status = StringProperty("तैयार")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if CONFIG_FILE.exists():
            try:
                data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
                self.api_url = data.get("api_url", "")
                self.profile_id = data.get("profile_id", "")
            except Exception:
                pass

    def save_api(self, value):
        self.api_url = value.strip().rstrip("/")
        self._save_config()
        self.status = "API URL सेव हो गया"

    def _save_config(self):
        CONFIG_FILE.write_text(json.dumps({
            "api_url": self.api_url,
            "profile_id": self.profile_id
        }), encoding="utf-8")

    def choose_sample(self):
        filechooser.open_file(on_selection=self._sample_selected,
                              filters=["*.wav", "*.mp3", "*.m4a", "*.flac"])

    def _sample_selected(self, selection):
        if selection:
            self.sample_path = selection[0]
            self.sample_name = Path(self.sample_path).name

    def choose_video(self):
        filechooser.open_file(on_selection=self._video_selected,
                              filters=["*.mp4", "*.mov", "*.mkv"])

    def _video_selected(self, selection):
        if selection:
            self.video_path = selection[0]
            self.video_name = Path(self.video_path).name

    def _check_api(self):
        if not self.api_url:
            raise RuntimeError("पहले Cloud API URL सेव करें")
        return self.api_url

    def upload_sample(self):
        if not self.sample_path:
            self.status = "पहले voice sample चुनें"
            return
        threading.Thread(target=self._upload_sample_worker, daemon=True).start()

    def _upload_sample_worker(self):
        try:
            self._check_api()
            self.set_status("Voice sample upload हो रहा है...")
            with open(self.sample_path, "rb") as audio:
                response = requests.post(
                    self.api_url + "/v1/voice-profiles",
                    files={"audio": (Path(self.sample_path).name, audio)},
                    data={"consent": "true"},
                    timeout=300
                )
            response.raise_for_status()
            result = response.json()
            self.profile_id = result.get("profile_id", "")
            self._save_config()
            self.set_profile_status("Profile ID सेव: " + (self.profile_id[:8] or "नहीं मिला"))
            self.set_status(result.get("message", result.get("status", "Upload पूरा")))
        except Exception as exc:
            self.set_status("Upload error: " + str(exc))

    def convert(self):
        if not self.video_path:
            self.status = "पहले वीडियो चुनें"
            return
        if not self.profile_id:
            self.status = "पहले voice sample upload करके profile बनाएँ"
            return
        threading.Thread(target=self._convert_worker, daemon=True).start()

    def _convert_worker(self):
        try:
            self._check_api()
            self.set_status("वीडियो server पर upload हो रहा है...")
            with open(self.video_path, "rb") as video:
                response = requests.post(
                    self.api_url + "/v1/conversions",
                    files={"video": (Path(self.video_path).name, video)},
                    data={
                        "profile_id": self.profile_id,
                        "mode": "voice_conversion",
                        "preserve_timing": "true",
                        "consent": "true"
                    },
                    timeout=600
                )
            response.raise_for_status()
            result = response.json()
            self.set_status("Job: " + str(result.get("job_id", "")) +
                            " | स्थिति: " + str(result.get("status", "")))
        except Exception as exc:
            self.set_status("Conversion request error: " + str(exc))

    def set_status(self, value):
        Clock.schedule_once(lambda dt: setattr(self, "status", value), 0)

    def set_profile_status(self, value):
        Clock.schedule_once(lambda dt: setattr(self, "profile_status", value), 0)


class MonuVoiceEditorApp(App):
    def build(self):
        Builder.load_string(KV)
        return Root()

if __name__ == "__main__":
    MonuVoiceEditorApp().run()
