import os
import uuid
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, Form, HTTPException

APP_NAME = "Monu AI Voice Editor API"
DATA_DIR = Path(os.getenv("DATA_DIR", "./data"))
PROFILE_DIR = DATA_DIR / "profiles"
UPLOAD_DIR = DATA_DIR / "uploads"
for directory in (PROFILE_DIR, UPLOAD_DIR):
    directory.mkdir(parents=True, exist_ok=True)

MAX_AUDIO_BYTES = 50 * 1024 * 1024
MAX_VIDEO_BYTES = 500 * 1024 * 1024
AUDIO_EXTENSIONS = {".wav", ".mp3", ".m4a", ".flac"}
VIDEO_EXTENSIONS = {".mp4", ".mov", ".mkv"}

app = FastAPI(title=APP_NAME, version="1.0.0")
profiles = {}
jobs = {}

async def save_limited_upload(upload: UploadFile, destination: Path, limit: int):
    total = 0
    try:
        with destination.open("wb") as output:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit:
                    raise HTTPException(status_code=413, detail="File exceeds size limit")
                output.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()
    return total

def require_consent(consent: str):
    if consent.strip().lower() != "true":
        raise HTTPException(status_code=403, detail="Voice owner consent is required")

@app.get("/")
def home():
    return {"app": APP_NAME, "status": "online", "docs": "/docs"}

@app.get("/health")
def health():
    return {
        "ok": True,
        "api": "online",
        "rvc_worker_connected": False,
        "ffmpeg_pipeline_connected": False
    }

@app.post("/v1/voice-profiles")
async def create_voice_profile(
    audio: UploadFile = File(...),
    consent: str = Form(...)
):
    require_consent(consent)
    extension = Path(audio.filename or "").suffix.lower()
    if extension not in AUDIO_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Unsupported audio format")
    profile_id = str(uuid.uuid4())
    destination = PROFILE_DIR / f"{profile_id}{extension}"
    size = await save_limited_upload(audio, destination, MAX_AUDIO_BYTES)
    profiles[profile_id] = {"profile_id": profile_id, "file": str(destination)}
    return {
        "profile_id": profile_id,
        "status": "uploaded_model_not_trained",
        "file_size": size,
        "message": "Sample uploaded. RVC model training worker is not connected."
    }

@app.post("/v1/conversions")
async def create_conversion(
    video: UploadFile = File(...),
    profile_id: str = Form(...),
    mode: str = Form("voice_conversion"),
    preserve_timing: str = Form("true"),
    consent: str = Form(...)
):
    require_consent(consent)
    if profile_id not in profiles:
        raise HTTPException(status_code=404, detail="Voice profile not found on this server")
    extension = Path(video.filename or "").suffix.lower()
    if extension not in VIDEO_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Unsupported video format")
    job_id = str(uuid.uuid4())
    destination = UPLOAD_DIR / f"{job_id}{extension}"
    size = await save_limited_upload(video, destination, MAX_VIDEO_BYTES)
    jobs[job_id] = {
        "job_id": job_id,
        "profile_id": profile_id,
        "status": "queued_model_not_connected",
        "progress": 0,
        "output_url": None
    }
    return {
        **jobs[job_id],
        "file_size": size,
        "mode": mode,
        "preserve_timing": preserve_timing,
        "message": "Video uploaded. RVC and FFmpeg workers are not connected; no converted file exists yet."
    }

@app.get("/v1/jobs/{job_id}")
def get_job(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    return jobs[job_id]
