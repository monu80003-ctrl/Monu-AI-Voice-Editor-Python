# अगला चरण: RVC + FFmpeg GPU Worker

यह starter अभी voice conversion नहीं करता। वास्तविक pipeline के लिए:
1. Secure authentication और profile ownership लागू करें।
2. Voice-owner consent record करें।
3. FFmpeg से source video का audio extract करें।
4. अनुमति-प्राप्त trained RVC model के साथ inference करें।
5. Output audio की duration/timing जाँचें।
6. FFmpeg से converted audio को source video में mux करें।
7. Job status, progress और private output download endpoint दें।
8. Profile deletion, data retention, encryption और access control लागू करें।

RVC voice conversion source delivery को बनाए रखने का प्रयास करता है। Cloned-voice TTS text से नई speech बनाता है; दोनों अलग कार्य हैं।
